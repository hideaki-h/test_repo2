# _work（一時出力）

Claudeが出す**一時・作業用の成果物**の置き場です。`.claude/rules/_work.md` のルールにより、Claudeは
`_work/<YYYY-MM-DD>_<サブジェクト>/`（例: `2026-06-15_AD移行調査/`）に出力します。

- ここは**使い捨て**。固まった成果物だけ `docs/runbooks/` や `.claude/skills/` へ昇格させます。
- 将来 git 化するときは `.gitignore` に `_work/` を1行足すだけで丸ごと管理外にできます。
- このREADME以外の中身は、不要になったら削除して構いません。
