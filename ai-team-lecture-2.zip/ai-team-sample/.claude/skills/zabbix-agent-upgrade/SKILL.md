---
name: zabbix-agent-upgrade
description: Zabbix agent を v1→v2 へアップグレードするときに使う。前後の監視抑止/解除・監視項目ステータス確認はClaudeで行い、本体の適用はAnsibleで一括実行するハイブリッド手順。インフラチーム向け。
---

# Zabbix agent アップグレード（要点）※サンプル

> `projects/zabbix-agent-upgrade/` で揉んで Phase1（20台）で検証した結果を、再利用できる形に昇格させたもの。

1. **事前確認（Claude）**：監視ステータス取得・正常性確認 → 監視抑止を投入
2. **実行（Ansible）**：対象群へ v2 を一括適用
3. **事後確認（Claude / log-investigator）**：ステータス前後比較で欠落・異常を確認 → 問題なければ抑止解除
4. **記録**：結果と課題を残す（run-sheet / issues.md）

- 大量のステータス確認・失敗ログ調査は `log-investigator` サブエージェントに投げる。
- 詳細・例外・ロールバック判断は `docs/runbooks/zabbix-agent-upgrade.md` を参照。
- 機密（ホスト名・IP・inventory）は焼き込まない（`[REDACTED]`）。
