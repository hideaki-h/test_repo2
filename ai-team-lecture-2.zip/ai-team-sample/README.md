# ai-team-sample（共有フォルダ構成サンプル）

レクチャー資料 `../ai-team-lecture.md` の **付録A** に対応する、共有フォルダ構成の**実物サンプル**です。
本番では、この一式をファイルサーバの共有フォルダ（例: `\\fileserver\ai-team\`）に置き、各メンバーがそこで `claude` を起動して使います。

## 使い方

1. この `ai-team-sample` フォルダ（本番では共有フォルダ）で `claude` を起動する。
2. `CLAUDE.md` / `.claude/rules` / `.claude/skills` / `.claude/settings.json` が自動で効く。
3. 良い手順・指示は Skill や `docs/runbooks/` として蓄積し、共有フォルダに戻す → 全員に反映。

## 構成

- `CLAUDE.md` … 共通ルール＋ディレクトリ構成マップ
- `.claude/settings.json` … 共有ガードレール（deny ルール）
- `.claude/rules/` … `_work_file_placement.md`(一時出力・常時適用)、`client.md`、`infra.md`
- `.claude/skills/` … `client-kitting`、`infra-log-check`、`zabbix-agent-upgrade`（サンプルSkill）
- `.claude/agents/` … `log-investigator`（ログ調査用サブエージェント。`memory: user`＝個人別メモリで競合回避）
- `.claude/log-policies/` … ログ調査の「人が書く共有方針」（例 `linux-syslog.md`）＋ `_candidates.md`（個人メモリからの昇格候補）
- ※ エージェント自動メモリは `memory: user` のため各自PCの `~/.claude/agent-memory/` にあり、共有フォルダには置かれない
- `docs/` … システム構成・アーキテクチャ／`docs/runbooks/`（手順書。`zabbix-agent-upgrade` は昇格済み例）
- `projects/<名>/` … 走行中サブプロジェクト（最小形 `sample-ad-migration`／発展形 `zabbix-agent-upgrade`）
- `_work/` … Claudeの一時出力（使い捨て）

> 中身はすべて**サンプル**です。自組織の実態に合わせて書き換えてください。
