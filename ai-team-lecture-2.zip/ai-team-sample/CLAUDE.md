# チーム共有AIワークスペース（共通ルール）

クライアントチーム（PC管理・保守）とインフラチーム（サーバ管理・保守）が、Claude Codeのインプット資産を蓄積・共有して使うための共有フォルダです。
このフォルダで `claude` を起動すると、ここの `CLAUDE.md` / `.claude/rules` / `.claude/skills` / `.claude/settings.json` が自動で効きます。

## ディレクトリ構成（どこに何があるか）

- `docs/`           … ドキュメント（システム構成・アーキテクチャ）。
- `docs/runbooks/`  … 仕上がった手順書（人も読む詳細ナレッジ）。
- `projects/<名>/`  … 走行中サブプロジェクトの管理資料・過渡期の成果物。
- `_work/<日付>_<件名>/` … 一時・作業用の出力先（使い捨て・将来 .gitignore 対象）。
- `.claude/log-policies/<種別>.md` … ログ調査の「人が書く共有方針」（`log-investigator` が調査開始時に読む）。`_candidates.md` は個人メモリからの昇格候補置き場。

（`.claude/skills/`・`.claude/rules/`・`.claude/agents/` は置いてあるだけでClaudeが自動で読み込む／呼び出せるため、ここには書かない。`log-investigator` の自動メモリは `memory: user`＝各自PCの `~/.claude/agent-memory/` にあり共有フォルダには無い）

## 最重要ルール

- 一時成果物は `_work/<日付>_<件名>/` に出す（詳細は `.claude/rules/_work_file_placement.md`）。
- 機密（鍵・パスワード・個人情報・内部IP体系）は資産に書かない。サンプルは `****` / `[REDACTED]` に置き換える。
- 調査はまず読み取り中心（plan モード）。**auto モードは原則禁止**。実行は1操作ずつ確認する。
- 生成物は必ず人間が確認してから実行する（特に削除・変更・本番反映）。
- ログ・障害調査は `log-investigator` サブエージェントを使う。人が書く共有方針は `.claude/log-policies/<種別>.md`、経験の蓄積は各自のエージェント自動メモリ（`memory: user`＝個人別・競合しない）に分ける。共有は `_candidates.md` 経由で人が `log-policies` へ昇格。

## 取り込み元のメモ

- OneNote（OneDrive上）・SharePoint Online は専用Skillで直接参照できる（いずれも実行時に対象のURLを一緒に渡す）。
- Excel / Word はDLPにより直接開けない。TSV やテキストに変換してから渡す。
- PDF・テキスト・CSV/TSV・画像（PNG/JPG）はそのまま渡せる。
