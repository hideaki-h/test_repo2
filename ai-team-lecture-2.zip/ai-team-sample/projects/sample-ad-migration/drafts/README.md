# drafts

作りかけの成果物・過渡期の構成変更を置く場所（サンプル）。
固まったら `docs/runbooks/` や `.claude/skills/` へ昇格させ、ここは整理・削除してよい。
