# Zabbix agent v1→v2 アップグレード 計画（サンプル）

## 目的・方針
- 目的：監視エージェント Zabbix agent を v1→v2 へ更新（対象 `[REDACTED]` 台）
- 方式：**実行 = Ansible ／ 前後の確認 = Claude Code**（ハイブリッド）
- 単純適用ではなく、**前後で「監視抑止/解除」と「監視項目ステータス確認」**を行い、移行で監視に穴・異常を出さないことを担保する。
- 安全：機密（ホスト名・IP・インベントリ）は本フォルダに直書きせず別管理（`[REDACTED]`）。

## フェーズ
- [x] Phase0：手順設計・runbook 作成（procedure.md）
- [x] Phase1：20台で検証 → 結果を skill 化（`.claude/skills/zabbix-agent-upgrade/`）
- [ ] Phase2：残り対象を群ごとに順次展開
- [ ] Phase3：全台完了・旧バージョン残存ゼロを確認

## 関連ファイル
- 共通手順：`runbook/procedure.md`
- 作業日ごと：`runbook/run-sheet_YYYYMMDD.md`
- 課題：`issues.md` ／ 進捗：`status.md` ／ 決定：`decisions.md`
- 昇格先：`docs/runbooks/zabbix-agent-upgrade.md`、`.claude/skills/zabbix-agent-upgrade/`
