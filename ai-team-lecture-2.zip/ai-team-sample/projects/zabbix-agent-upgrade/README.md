# サブプロジェクト: Zabbix agent v1→v2 アップグレード（サンプル）

> `projects/<名>/` の**発展形サンプル**（大規模・多フェーズ案件向け）。
> `sample-ad-migration/`（STATUS.md/notes/drafts の最小形）に対し、こちらは計画・課題・進捗・手順・作業記録を1フォルダに集約した形です。

## 概要
- 目的：監視エージェント Zabbix agent を v1→v2 へ更新（対象 `[REDACTED]` 台規模）
- 方式：**実行 = Ansible ／ 前後の確認 = Claude Code**（ハイブリッド）

## ファイルの役割
- `plan.md` … 全体計画（フェーズ分け・段取り）
- `issues.md` … 課題・ブロッカー・判断待ち
- `status.md` … 報告に適した進捗サマリ（Claudeに更新させる）
- `decisions.md` … 意思決定ログ（なぜAnsible／なぜ前後確認をClaudeに、等）
- `runbook/procedure.md` … 共通手順の本体（再利用する手順）
- `runbook/run-sheet_YYYYMMDD.md` … procedure を参照し、その作業日のパラメータを埋めた実行シート

## 昇格
固まった共通手順は `docs/runbooks/zabbix-agent-upgrade.md` へ、繰り返す定型は
`.claude/skills/zabbix-agent-upgrade/` へ昇格済み（本サンプルに同梱）。

> 機密（ホスト名・IP・inventory）は本フォルダに直書きせず別管理（`[REDACTED]`）。
