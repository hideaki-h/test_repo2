# Zabbix agent アップグレード 共通手順（procedure）※サンプル

> これは**再利用する手順の本体**。作業日ごとの対象・パラメータは `run-sheet_YYYYMMDD.md` 側に書く。
> ここにはホスト名・IP・inventory を書かない（`[REDACTED]`）。

## 前提
- 対象群・認証情報・playbook 名は run-sheet 側で指定する。

## 手順
1. **事前確認（Claude Code）**
   - 対象群の監視ステータス取得・正常性確認
   - 監視抑止（メンテナンスモード）を投入
2. **実行（Ansible）**
   - 対象群へ v2 を一括適用（playbook: `[REDACTED]`）
3. **事後確認（Claude Code / log-investigator）**
   - 監視項目ステータスを確認し、**前後比較**で欠落・異常がないか検証
   - 問題なければ監視抑止を解除
4. **記録**
   - 結果を run-sheet に追記。異常・気づき・新たな課題は `issues.md` へ

## 中止・ロールバック
- 事後確認で重大な欠落・異常を検知したら、**抑止は維持**したまま `issues.md` に記録し、人間の判断を仰ぐ。

## 補足
- 大量のステータス確認・失敗ログの調査は `log-investigator` サブエージェントに投げる（メインの文脈を膨らませない）。
- 詳細・背景・例外は `docs/runbooks/zabbix-agent-upgrade.md` を参照。
