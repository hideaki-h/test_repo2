# ai-team-sample（共有フォルダ構成サンプル）

レクチャー資料 `../ai-team-lecture.md` の **付録A** に対応する、共有フォルダ構成の**実物サンプル**です。
本番では、この一式をファイルサーバの共有フォルダ（例: `\\fileserver\ai-team\`）に置き、各メンバーがそこで `claude` を起動して使います。

## 使い方

1. この `ai-team-sample` フォルダ（本番では共有フォルダ）で `claude` を起動する。
2. `CLAUDE.md` / `.claude/rules` / `.claude/skills` / `.claude/settings.json` が自動で効く。
3. 良い手順・指示は Skill や `docs/runbooks/` として蓄積し、共有フォルダに戻す → 全員に反映。

## 構成

- `CLAUDE.md` … 共通ルール＋ディレクトリ構成マップ
- `.claude/settings.json` … 共有ガードレール（deny ルール）
- `.claude/rules/` … `_work.md`（一時出力・常時適用）、`client.md`、`infra.md`
- `.claude/skills/` … `client-kitting`、`infra-log-check`（サンプルSkill）
- `docs/` … システム構成・アーキテクチャ／`docs/runbooks/`（手順書）
- `projects/<名>/` … 走行中サブプロジェクト（`STATUS.md`/`notes`/`drafts`）
- `_work/` … Claudeの一時出力（使い捨て）

> 中身はすべて**サンプル**です。自組織の実態に合わせて書き換えてください。
